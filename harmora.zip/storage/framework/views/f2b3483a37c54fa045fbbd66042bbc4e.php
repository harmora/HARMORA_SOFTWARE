<!-- Footer -->
<div id="section-not-to-print">
    <footer class="content-footer footer bg-footer-theme mt-4">
        <div class="container-fluid d-flex flex-wrap justify-content-between flex-md-row flex-column">
            <div class="mb-md-0 d-flex align-items-start justify-content-between">
                ©
                <script>
                    document.write(new Date().getFullYear());
                </script>
                , TEXT AS A FOUTER
                <p class="mx-4 fw-bolder">v<?php echo e(get_current_version()); ?></p>
            </div>
        </div>
    </footer>
</div>
<!-- / Footer -->
<?php /**PATH C:\xampp\htdocs\harmora v2\harmora\resources\views/components/footer.blade.php ENDPATH**/ ?>