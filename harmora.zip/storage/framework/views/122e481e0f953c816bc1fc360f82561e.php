<?php $__env->startSection('title'); ?>
<?= get_label('disponibility', 'Disponibility') ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between mb-2 mt-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/home')); ?>"><?= get_label('home', 'Home') ?></a>
                    </li>
                    <li class="breadcrumb-item active">
                        <?= get_label('disponibility', 'Disponibility') ?>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#createMeetingModal"><button type="button" class="btn btn-sm btn-primary " data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="<?= get_label('add_reservation', 'Add Reservation') ?>"><i class='bx bx-plus'></i></button></a>
            
        </div>
    </div>
    
    <?php if (isset($component)) { $__componentOriginal2d507d601c92724784da78df4158e631 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d507d601c92724784da78df4158e631 = $attributes; } ?>
<?php $component = App\View\Components\DisponibilityCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('disponibility-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DisponibilityCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d507d601c92724784da78df4158e631)): ?>
<?php $attributes = $__attributesOriginal2d507d601c92724784da78df4158e631; ?>
<?php unset($__attributesOriginal2d507d601c92724784da78df4158e631); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d507d601c92724784da78df4158e631)): ?>
<?php $component = $__componentOriginal2d507d601c92724784da78df4158e631; ?>
<?php unset($__componentOriginal2d507d601c92724784da78df4158e631); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\harmora\resources\views/disponibility/disponibility.blade.php ENDPATH**/ ?>