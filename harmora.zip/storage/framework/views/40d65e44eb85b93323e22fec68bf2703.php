<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <?php echo str_replace('{COMPANY_LOGO}', '<img src="' . $logo_url . '" width="200px" alt="" />', $content); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\harmora\resources\views/mail/html.blade.php ENDPATH**/ ?>