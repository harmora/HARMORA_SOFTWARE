<?php return [


'redirect_url' => '/settings/languages',
'type' => 'email',
'name' => 'email_verification',
'subject' => '',
'content' => '',
];